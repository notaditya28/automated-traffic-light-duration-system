"""
Automated Traffic Light Duration System
Author: Aditya Nahata | Roll No: 1024240083 | Group: 2X13
Subject: UTA035 - Engineering Design Project (Edge Computing)
Platform: NVIDIA Jetson Nano — HEADLESS MODE (terminal output only)
"""

import cv2
import time
import argparse
import numpy as np
from utils.detector import VehicleDetector
from utils.traffic_controller import TrafficController
from utils.display import DisplayManager

def parse_args():
    parser = argparse.ArgumentParser(description="Automated Traffic Light Duration System")
    parser.add_argument("--source", type=str, default="0",
                        help="Camera index (0) or video file path")
    parser.add_argument("--model", type=str, default="yolov8n.pt",
                        help="YOLO model path (yolov8n.pt recommended for Jetson Nano)")
    parser.add_argument("--conf", type=float, default=0.4,
                        help="Detection confidence threshold")
    parser.add_argument("--lanes", type=int, default=2,
                        help="Number of traffic lanes to manage")
    parser.add_argument("--min-green", type=int, default=10,
                        help="Minimum green light duration (seconds)")
    parser.add_argument("--max-green", type=int, default=60,
                        help="Maximum green light duration (seconds)")
    parser.add_argument("--save", action="store_true",
                        help="Save output video")
    return parser.parse_args()


def main():
    args = parse_args()

    # --- Source ---
    source = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"[ERROR] Could not open source: {args.source}")
        return

    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps    = cap.get(cv2.CAP_PROP_FPS) or 30

    print(f"[INFO] Source opened: {width}x{height} @ {fps:.1f} FPS")
    print("[INFO] Running in HEADLESS mode — results printed to terminal.")
    print("[INFO] Press Ctrl+C to stop.\n")

    # --- Components ---
    detector   = VehicleDetector(model_path=args.model, conf=args.conf)
    controller = TrafficController(
        num_lanes=args.lanes,
        min_green=args.min_green,
        max_green=args.max_green
    )
    display    = DisplayManager(width, height, num_lanes=args.lanes)

    # --- Optional video writer ---
    writer = None
    if args.save:
        out_path = "output_traffic.avi"
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        writer = cv2.VideoWriter(out_path, fourcc, fps, (width, height))
        print(f"[INFO] Saving output to {out_path}")

    frame_count = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[INFO] End of stream.")
                break

            frame_count += 1

            # --- Detection ---
            detections, vehicle_counts = detector.detect(
                frame, num_lanes=args.lanes, frame_w=width
            )

            # --- Controller update ---
            controller.update(vehicle_counts)
            signal_states  = controller.get_signal_states()
            green_times    = controller.get_green_durations(vehicle_counts)
            time_remaining = controller.get_time_remaining()

            # --- Terminal output (headless) ---
            output = display.draw(
                frame,
                detections,
                signal_states,
                vehicle_counts,
                green_times,
                time_remaining,
                frame_count
            )

            # --- Save video if requested ---
            if writer:
                writer.write(output)

    except KeyboardInterrupt:
        print("\n[INFO] Stopped by user (Ctrl+C).")

    finally:
        cap.release()
        if writer:
            writer.release()
        print("[INFO] System stopped cleanly.")


if __name__ == "__main__":
    main()