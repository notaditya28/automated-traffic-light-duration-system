# Automated Traffic Light Duration System
**Author:** Aditya Nahata | **Roll No:** 1024240083 | **Group:** 2X13  
**Subject:** UTA035 – Engineering Design Project (Edge Computing)  
**Platform:** NVIDIA Jetson Nano

---

## Project Structure

```
traffic_light_project/
├── main.py               # Entry point
├── requirements.txt      # Dependencies
├── README.md
├── utils/
│   ├── detector.py       # YOLOv8 vehicle detection
│   ├── traffic_controller.py  # Adaptive duration algorithm
│   └── display.py        # OpenCV overlay rendering
├── models/               # Place yolov8n.pt here
└── data/                 # Sample videos for testing
```

---

## Installation

```bash
# On Jetson Nano (JetPack 4.6)
pip install -r requirements.txt --break-system-packages

# Download YOLOv8 nano model (auto-downloaded on first run)
# Or manually: https://github.com/ultralytics/assets/releases
```

---

## Usage

```bash
# Run with webcam (default)
python main.py --source 0

# Run with a video file
python main.py --source data/traffic.mp4

# Custom settings
python main.py --source 0 --lanes 2 --min-green 10 --max-green 60 --conf 0.4

# Save output video
python main.py --source 0 --save
```

---

## Adaptive Algorithm

```
green_time = clamp(BASE_TIME + vehicle_count × TIME_PER_VEHICLE, min_green, max_green)

BASE_TIME        = 10 seconds
TIME_PER_VEHICLE =  2 seconds / vehicle
Default range    = [10, 60] seconds
```

Example:
- 0 vehicles  → 10s green
- 5 vehicles  → 20s green
- 15 vehicles → 40s green
- 25 vehicles → 60s green (capped)

---

## Signal Cycle

```
Lane 0 GREEN (adaptive duration) → YELLOW (3s) → RED
Lane 1 GREEN (adaptive duration) → YELLOW (3s) → RED
→ repeat
```
