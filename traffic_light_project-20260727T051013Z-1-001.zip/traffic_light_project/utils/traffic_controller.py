"""
utils/traffic_controller.py
Adaptive Traffic Light Controller — Headless version
"""

import time

YELLOW_DURATION = 3  # seconds

class TrafficController:
    def __init__(self, num_lanes=2, min_green=10, max_green=60):
        self.num_lanes  = num_lanes
        self.min_green  = min_green
        self.max_green  = max_green

        # State per lane: "GREEN", "YELLOW", "RED"
        self.states         = ["RED"] * num_lanes
        self.states[0]      = "GREEN"   # Lane 0 starts green
        self.current_lane   = 0
        self.phase_start    = time.time()
        self.current_duration = min_green  # will be updated on first update()

    # ------------------------------------------------------------------ #
    def _calc_green(self, vehicle_count):
        """Formula: base(10s) + 2s per vehicle, clamped to [min, max]."""
        BASE            = 10
        TIME_PER_VEHICLE = 2
        t = BASE + vehicle_count * TIME_PER_VEHICLE
        return max(self.min_green, min(self.max_green, t))

    # ------------------------------------------------------------------ #
    def update(self, vehicle_counts):
        """Call every frame. Advances phase when timer expires."""
        elapsed = time.time() - self.phase_start
        lane    = self.current_lane

        if self.states[lane] == "GREEN":
            green_dur = self._calc_green(vehicle_counts[lane])
            self.current_duration = green_dur
            if elapsed >= green_dur:
                self.states[lane] = "YELLOW"
                self.phase_start  = time.time()

        elif self.states[lane] == "YELLOW":
            if elapsed >= YELLOW_DURATION:
                self.states[lane] = "RED"
                # Advance to next lane
                self.current_lane = (lane + 1) % self.num_lanes
                self.states[self.current_lane] = "GREEN"
                self.phase_start  = time.time()

    # ------------------------------------------------------------------ #
    def get_signal_states(self):
        return list(self.states)

    def get_green_durations(self, vehicle_counts):
        return [self._calc_green(c) for c in vehicle_counts]

    def get_time_remaining(self):
        elapsed = time.time() - self.phase_start
        lane    = self.current_lane

        if self.states[lane] == "GREEN":
            remaining = max(0, self.current_duration - elapsed)
        elif self.states[lane] == "YELLOW":
            remaining = max(0, YELLOW_DURATION - elapsed)
        else:
            remaining = 0.0

        return round(remaining, 1)