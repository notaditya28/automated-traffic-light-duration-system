"""
utils/detector.py
YOLOv8 Vehicle Detector — Headless version
"""

from ultralytics import YOLO
import numpy as np

# COCO class IDs for vehicles
VEHICLE_CLASSES = {
    2:  "car",
    3:  "motorcycle",
    5:  "bus",
    7:  "truck",
}

class VehicleDetector:
    def __init__(self, model_path="yolov8n.pt", conf=0.4):
        print(f"[INFO] Loading YOLO model: {model_path}")
        self.model = YOLO(model_path)
        self.conf  = conf
        print("[INFO] Model loaded successfully.")

    def detect(self, frame, num_lanes=2, frame_w=640):
        """
        Run detection on frame.
        Returns:
            detections   : list of dicts {bbox, class_name, confidence, lane}
            vehicle_counts: list of int, count per lane
        """
        results = self.model(frame, conf=self.conf, verbose=False)[0]

        detections    = []
        vehicle_counts = [0] * num_lanes
        lane_width     = frame_w / num_lanes

        for box in results.boxes:
            cls_id = int(box.cls[0])
            if cls_id not in VEHICLE_CLASSES:
                continue

            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf_score      = float(box.conf[0])
            class_name      = VEHICLE_CLASSES[cls_id]

            # Determine lane by center-x of bounding box
            cx   = (x1 + x2) // 2
            lane = min(int(cx / lane_width), num_lanes - 1)

            detections.append({
                "bbox":       (x1, y1, x2, y2),
                "class_name": class_name,
                "confidence": conf_score,
                "lane":       lane
            })
            vehicle_counts[lane] += 1

        return detections, vehicle_counts