"""
utils/display.py
DisplayManager — Headless / Terminal-only version
No cv2.imshow() used. Prints a clean dashboard to terminal every N frames.
"""

import time

class DisplayManager:
    def __init__(self, width, height, num_lanes=2, print_every=15):
        self.width       = width
        self.height      = height
        self.num_lanes   = num_lanes
        self.print_every = print_every   # print every N frames
        self._start_time = time.time()

    # ------------------------------------------------------------------ #
    def draw(self, frame, detections, signal_states,
             vehicle_counts, green_times, time_remaining, frame_count):
        """
        In headless mode we don't draw on screen.
        Every `print_every` frames we print a status dashboard to terminal.
        Returns the original frame unchanged (used by --save if enabled).
        """
        if frame_count % self.print_every == 0:
            self._print_dashboard(
                frame_count, signal_states,
                vehicle_counts, green_times, time_remaining, detections
            )
        return frame   # return raw frame (used by VideoWriter if --save)

    # ------------------------------------------------------------------ #
    def _print_dashboard(self, frame_count, signal_states,
                         vehicle_counts, green_times, time_remaining, detections):
        elapsed = time.time() - self._start_time
        mins    = int(elapsed // 60)
        secs    = int(elapsed % 60)

        print("\n" + "=" * 52)
        print(f"  🚦 TRAFFIC LIGHT SYSTEM  |  Frame: {frame_count:>5}  |  {mins:02d}:{secs:02d}")
        print("=" * 52)

        for lane in range(self.num_lanes):
            state    = signal_states[lane]
            count    = vehicle_counts[lane]
            gt       = green_times[lane]

            # Signal emoji
            icon = {"GREEN": "🟢", "YELLOW": "🟡", "RED": "🔴"}.get(state, "⚫")

            print(f"  Lane {lane}  {icon} {state:<6}  |  "
                  f"Vehicles: {count:>2}  |  Green: {gt:>4.0f}s")

        print(f"  ⏱  Time remaining in current phase: {time_remaining}s")

        # Vehicle breakdown
        total = sum(vehicle_counts)
        types = {}
        for d in detections:
            cn = d["class_name"]
            types[cn] = types.get(cn, 0) + 1

        print(f"  🚗 Total vehicles detected: {total}", end="")
        if types:
            breakdown = "  (" + ", ".join(f"{v} {k}" for k, v in types.items()) + ")"
            print(breakdown, end="")
        print()
        print("=" * 52)